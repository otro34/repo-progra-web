import Alumnos from '../../app/alumnos/Alumnos.jsx'

const AlumnosPage = () => {
    return (
        <Alumnos />
    )
}

export default AlumnosPage