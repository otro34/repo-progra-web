function About() {
    return <h1>Acerca De</h1>
}

export default About