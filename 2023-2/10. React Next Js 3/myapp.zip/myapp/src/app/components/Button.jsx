function Button () {
    return (<button>CLICK ME!</button>)
}

export default Button