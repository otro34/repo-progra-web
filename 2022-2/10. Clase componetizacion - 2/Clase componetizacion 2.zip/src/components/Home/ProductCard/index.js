import ProductCard from './ProductCard'

export default ProductCard