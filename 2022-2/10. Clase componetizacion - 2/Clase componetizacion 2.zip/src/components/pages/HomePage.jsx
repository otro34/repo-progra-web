import Layout from '../layout/Layout'
import Home from '../Home'

const HomePage = () => {
    return (
        <>
        <Layout
            main={<Home />}>
                
            </Layout>
        </>)

}

export default HomePage;