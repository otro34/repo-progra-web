const Error404Page = () => {
    return(
        <>
        <img src="img/error404.jpg" alt="error!" />
        </>
    )
}

export default Error404Page;