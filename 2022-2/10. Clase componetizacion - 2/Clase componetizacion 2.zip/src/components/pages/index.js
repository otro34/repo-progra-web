export {default as HomePage} from './HomePage'
export {default as ContactPage} from './ContactPage'
export {default as Error404Page} from './Error404Page'