const ContactUs = () => {
    return <h1>PAGINA DE CONTACTO</h1>
}

export default ContactUs