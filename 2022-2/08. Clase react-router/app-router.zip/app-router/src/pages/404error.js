const Error404 = () => {
    return <h1>PAGE NOT FOUND</h1>
}

export default Error404