import Matricula from '../components/matricula/Matricula.jsx'

const MatriculaPage = () => {
    return <Matricula />
}

export default MatriculaPage