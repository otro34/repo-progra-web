import { useState, useEffect } from 'react'
import './App.css'

function App() {

  return (
    <>
      <h1>Sistema de Matrícula</h1>
      <ol>
        <li>Alumnos</li>
        <li>Cursos</li>
        <li><a href="/matricula">Matrícula</a></li>
      </ol>
    </>
  )
}

export default App
