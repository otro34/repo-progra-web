const matricula = [
{
    id: 1, 
    fechaMatricula: new Date(2024,1,1), 
    idAlumno: 1, 
    cursos: [{ id: 1 }, { id: 2 }],
    alumno: { id: 1 }
},
{
    id: 2, 
    fechaMatricula: new Date(2024,1,1), 
    idAlumno: 2, 
    cursos: [{ id: 3 }, { id: 4 }],
    alumno: { id: 2 }
}
]

export default matricula;