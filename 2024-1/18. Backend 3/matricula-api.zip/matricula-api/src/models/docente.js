const docentes = [
    { id:1, name: "Docente 1", email: "docente1@docente.com", code: "201"},
    { id:2, name: "Docente 2", email: "docente2@docente.com", code: "202"}
]

export default docentes;