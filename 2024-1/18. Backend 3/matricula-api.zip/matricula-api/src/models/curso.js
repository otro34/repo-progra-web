const cursos = [
    {id: 1, name: "Programación Web", nivel: 7, carrera: "Ing. Sistemas"},
    {id: 2, name: "Programación Orientada a Objetos", nivel: 4, carrera: "Ing. Sistemas"},
    {id: 3, name: "Interacción Persona-Computador", nivel: 5, carrera: "Ing. Sistemas"},
    {id: 4, name: "Gestión de Proyectos de Software", nivel: 8, carrera: "Ing. Sistemas"},
]

export default cursos;