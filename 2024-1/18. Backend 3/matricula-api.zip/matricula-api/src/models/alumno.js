const alumnos = [
    { id: 1, nombre: 'Juan', apellido: 'Perez', edad: 20 },
    { id: 2, nombre: 'Carlos', apellido: 'Robles', edad: 17 },
    { id: 3, nombre: 'Cristian', apellido: 'Sanchez', edad: 17 },
    { id: 4, nombre: 'Rodolfo', apellido: 'Arellano', edad: 18 },
]

export default alumnos;