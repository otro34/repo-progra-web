self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\src\\app\\page.js": [
      "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\src\\app\\page.module.css"
    ],
    "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\src\\app\\layout.js": [
      "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\node_modules\\next\\font\\google\\target.css?{\"path\":\"src\\\\app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\node_modules\\bootstrap\\dist\\css\\bootstrap.css",
      "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\src\\app\\globals.css"
    ]
  },
  "cssModules": {
    "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\src\\app\\page": [
      "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\node_modules\\bootstrap\\dist\\css\\bootstrap.css",
      "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\src\\app\\globals.css",
      "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\node_modules\\next\\font\\google\\target.css?{\"path\":\"src\\\\app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ],
    "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\src\\app\\docentes\\page": [
      "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\node_modules\\bootstrap\\dist\\css\\bootstrap.css",
      "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\src\\app\\globals.css",
      "E:\\repositorios\\repo-progra-web\\2023-1\\150. Clase conexión con front\\Inicial\\frontend\\node_modules\\next\\font\\google\\target.css?{\"path\":\"src\\\\app\\\\layout.js\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}"
    ]
  }
}