'use client';

import Header from '../../components/Header/Header'

const AboutUs = () => {
    return (
        <div>
            <Header />
            <h2>
            ACERCA DE NOSOTROS
            </h2>
            <button type="button" className="btn btn-primary">Primary</button>
        </div>

    )
} 

export default AboutUs