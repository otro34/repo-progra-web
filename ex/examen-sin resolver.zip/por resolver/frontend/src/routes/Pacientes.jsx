import Paciente from '../components/paciente/Paciente.jsx'

const Pacientes = () => {
    return <Paciente />
}

export default Pacientes