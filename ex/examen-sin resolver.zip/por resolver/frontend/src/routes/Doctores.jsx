import Doctor from '../components/doctor/Doctor.jsx'

const Doctores = () => {
    return <Doctor />
}

export default Doctores