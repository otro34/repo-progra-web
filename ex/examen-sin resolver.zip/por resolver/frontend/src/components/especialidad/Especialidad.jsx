const Especialidad = () => {
    return (
        <h2>Especialidad</h2>
    )
}

export default Especialidad;