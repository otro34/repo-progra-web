const Cita = () => {
    return (
        <h2>Cita</h2>
    )
}

export default Cita