const doctores = [
    {
        id: 1, nombre: 'Dr. Hugo Sanches', especialidadId: 1
    },
    {
        id: 2, nombre: 'Dra. Marta Sánchez', especialidadId: 2
    },
    {
        id: 3, nombre: 'Dr. Estupefacto Ascevedo', especialidadId: 3
    },
    {
        id: 4, nombre: 'Dra. Isabell Rosselini', especialidadId: 4
    },
    {
        id: 5, nombre: 'Dr. Ismael del Cuadro', especialidadId: 3
    },
    {
        id: 6, nombre: 'Dra. Clauduvica Paleta', especialidadId: 6
    },
    {
        id: 7, nombre: 'Dr. Godofredo Carrión', especialidadId: 7
    },
    {
        id: 8, nombre: 'Dra. Agustiniana Flores', especialidadId: 8
    },
    {
        id: 9, nombre: 'Dr. Diego Esperanza', especialidadId: 1
    },
    {
        id: 10, nombre: 'Dra. Ermenegildo Zenia', especialidadId: 2
    },
    {
        id: 11, nombre: 'Dr. Andrés Camalaro', especialidadId: 3
    },
    {
        id: 12, nombre: 'Dra. Eudofresia Tipomarina', especialidadId: 4
    },
    {
        id: 13, nombre: 'Dr. Hernán Lasio', especialidadId: 5
    },
    {
        id: 14, nombre: 'Dra. Diego Armando Ronaldo', especialidadId: 6
    },
    {
        id: 15, nombre: 'Dr. Juan Pérez', especialidadId: 7
    },
    {
        id: 16, nombre: 'Dra. María Gómez', especialidadId: 8
    },
    {
        id: 17, nombre: 'Dr. Carlos López', especialidadId: 1
    },
    {
        id: 18, nombre: 'Dra. Ana Martínez', especialidadId: 2
    },
    {
        id: 19, nombre: 'Dr. Pedro Rodríguez', especialidadId: 3
    },
    {
        id: 20, nombre: 'Dra. Laura Hernández', especialidadId: 4
    }
]

export default doctores;