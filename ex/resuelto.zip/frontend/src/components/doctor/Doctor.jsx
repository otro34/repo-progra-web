const Doctor = () => {
    return (
            <h2>Doctor</h2>
    );
}

export default Doctor