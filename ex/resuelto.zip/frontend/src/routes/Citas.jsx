import Cita from '../components/cita/Cita.jsx'

const Citas = () => {
    return <Cita />
}

export default Citas