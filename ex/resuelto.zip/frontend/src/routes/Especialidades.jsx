import Especialidad from '../components/especialidad/Especialidad.jsx'

const Especialidades = () => {
    return <Especialidad />
}

export default Especialidades