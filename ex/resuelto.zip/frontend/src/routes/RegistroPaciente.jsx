import Registro from '../components/paciente/Registro.jsx'

const RegistroPaciente = () => {
    return <Registro />
}

export default RegistroPaciente