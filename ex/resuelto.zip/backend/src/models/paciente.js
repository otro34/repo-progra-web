const pacientes = [
    {
        id: 1, nombre: 'Juan', apellido: 'Perez', edad: 20, fechaNacimiento: '2004-01-01'
    },
    {
        id: 2, nombre: 'María', apellido: 'Gómez', edad: 25, fechaNacimiento: '1999-01-01'
    },
    {
        id: 3, nombre: 'Carlos', apellido: 'López', edad: 30, fechaNacimiento: '1995-01-01'
    },
    {
        id: 4, nombre: 'Ana', apellido: 'Martínez', edad: 35, fechaNacimiento: '1990-01-01'
    },
    {
        id: 5, nombre: 'Pedro', apellido: 'Rodríguez', edad: 28, fechaNacimiento: '1997-01-01'
    },
    {
        id: 6, nombre: 'Laura', apellido: 'Hernández', edad: 22, fechaNacimiento: '2002-01-01'
    },
    {
        id: 7, nombre: 'Luis', apellido: 'González', edad: 40, fechaNacimiento: '1984-01-01'
    },
    {
        id: 8, nombre: 'Sofía', apellido: 'López', edad: 32, fechaNacimiento: '1993-01-01'
    },
    {
        id: 9, nombre: 'Diego', apellido: 'Torres', edad: 27, fechaNacimiento: '1998-01-01'
    },
    {
        id: 10, nombre: 'Carolina', apellido: 'Ramírez', edad: 29, fechaNacimiento: '1996-01-01'
    },
    {
        id: 11, nombre: 'Andrés', apellido: 'Fernández', edad: 33, fechaNacimiento: '1992-01-01'
    },
    {
        id: 12, nombre: 'Valentina', apellido: 'García', edad: 24, fechaNacimiento: '2000-01-01'
    },
    {
        id: 13, nombre: 'Javier', apellido: 'Silva', edad: 31, fechaNacimiento: '1993-01-01'
    },
    {
        id: 14, nombre: 'Isabella', apellido: 'Rojas', edad: 26, fechaNacimiento: '1998-01-01'
    }
];

export default pacientes;